"""Recompute the numbers in Section 7 of the paper that ka_empc_greenhouse.py
does not write to results_macros.tex.

Run after ka_empc_greenhouse.py (or on the supplied results/ folder):
    python3 check_text_numbers.py
It reads results_raw.pkl and prints, for each season,
  - the growth of the KRLS dictionary by day (Section 7.2),
  - the switch, fallback and refusal counts (Section 7.2),
  - the mean night and day ventilation (night: no solar radiation) and the
    mean heating during sub-zero outdoor temperatures (Sections 7.3, 7.4),
  - the mean one-step temperature error of the prior along the NMPC loop at
    night and in sub-zero weather (Section 7.4),
  - the largest tube half-width of the two predictions in Fig. 8 (Section 7.6),
  - the share of infeasible samples and of dictionary updates that fall in
    the winter cold snap (Section 7.2),
  - the ratio of the winter minimum-temperature violation integrals of the
    rule-based controller and KA-EMPC (Section 7.5).
"""
import os
import pickle
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ka_empc_greenhouse as K  # noqa: E402

SPD = K.STEPS_PER_DAY


def main():
    path = os.path.join(HERE, "results_raw.pkl")
    if not os.path.exists(path):                       # layout of the archive
        path = os.path.join(HERE, "results", "results_raw.pkl")
    with open(path, "rb") as f:
        out = pickle.load(f)
    for s in ["summer", "winter"]:
        r = out[("KA-EMPC", s, 2.0)]
        d = np.asarray(r["dict"])
        print(f"=== {s} ===")
        print("  new dictionary atoms by end of day 1..7:",
              [int(d[min(SPD * k - 1, len(d) - 1)] - d[0]) for k in range(1, 8)])
        print(f"  switches {r['n_switch']}, of which fallback {r['n_switch_fallback']}, "
              f"refused {r['n_reject']}")
        wx = r["weather"]
        rad, t_out = wx[:, 0], wx[:, 2]
        for c in ["RB", "NMPC", "KA-EMPC"]:
            u = np.asarray(out[(c, s, 2.0)]["u"])
            n = len(u)
            night = rad[:n] < 1.0
            sub = t_out[:n] < 0.0
            heat = f"{u[sub, 2].mean():.1f} W m-2" if sub.any() else "n/a"
            print(f"  {c:8s} ventilation night {u[night, 1].mean():.2f}, day {u[~night, 1].mean():.2f} mm s-1;"
                  f" heating below 0 C outside: {heat}")
        if s == "winter":
            rr = out[("NMPC", s, 2.0)]
            x, u = np.asarray(rr["x"]), np.asarray(rr["u"])
            n = len(u)
            e = np.array([K.prior_step(x[k], u[k], wx[k])[2] - x[k + 1, 2] for k in range(n - 1)])
            print(f"  prior one-step temperature bias along NMPC loop (prior - true): "
                  f"night {e[rad[:n - 1] < 1.0].mean():.2f} K, sub-zero {e[t_out[:n - 1] < 0].mean():.2f} K")
            for j, t in enumerate(r["tube_T"]):
                print(f"  Fig. 8 prediction {j + 1}: largest tube half-width {np.max(t):.2f} K")
            i_inf = np.where(r["pen2"] > 0.0)[0]
            i_up = np.where(np.diff(d) > 0)[0] + 1
            snap = lambda i: np.mean((i >= 3 * SPD) & (i < 5 * SPD))
            print(f"  share during the cold snap (days 4-5): infeasible samples {snap(i_inf):.2f}, "
                  f"dictionary updates {snap(i_up):.2f}")
            m_rb = K.metrics(out[("RB", s, 2.0)])
            m_ka = K.metrics(r)
            print(f"  T_min violation integral RB / KA-EMPC: "
                  f"{m_rb['Tlo']['integral'] / m_ka['Tlo']['integral']:.1f}")


if __name__ == "__main__":
    main()
