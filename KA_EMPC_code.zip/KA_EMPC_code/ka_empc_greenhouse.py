#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Uncertainty-Aware Adaptive Economic MPC via Kernel Learning (KA-EMPC)
for a Venlo-type lettuce greenhouse.

This script reproduces the figures, the results table and the numbers of
Section 7 of the paper
"Uncertainty-Aware Adaptive Economic MPC via Kernel Learning for Robust
Greenhouse Climate Management" (check_text_numbers.py recomputes the few
remaining numbers of the text from results_raw.pkl).

Contents
--------
1.  Van Henten lettuce greenhouse model (true plant, RK4, Ts = 900 s).
2.  Mis-calibrated physics prior f0 used by every model-based controller.
3.  Synthetic but physically consistent summer / winter weather, weather
    forecasts with lead-time dependent errors, and a time-of-use heat tariff.
4.  KRLS learner with an approximate-linear-dependence (ALD) novelty test,
    recursive inverse-Gram update and regularised posterior variance.
5.  Controllers
      - RB   : rule-based controller (PI heating, P ventilation, gated CO2),
      - NMPC : offset-free nominal economic NMPC on f0 (filtered output-
               disturbance estimate; no learning, no tightening, no tail),
      - KA-EMPC : f0 + KRLS residual, variance-driven constraint
                  tightening, finite-tail rollout of the base policy kappa,
                  accept-if-feasible model switching with the fallback rule of
                  Table 3 (Section 6.5 lists all differences from the
                  analysed controller).
6.  Metrics, a tightening sweep over the confidence multiplier beta, and
    PDF figures written to ./FIG/ (fig_bars.pdf is a supplementary
    summary that the manuscript replaces by Table 5), and the LaTeX files
    results_macros.tex / results_table.tex read by the manuscript.

Usage
-----
    python3 ka_empc_greenhouse.py            # full study (all figures/tables)
    python3 ka_empc_greenhouse.py --days 2   # quick smoke test

Dependencies: numpy, scipy, matplotlib (standard scientific Python).
All random quantities are seeded, so repeated runs give identical numbers
(apart from the measured solve times). The full study takes about 30 min
on four cores; --plot-only rebuilds figures and tables from results_raw.pkl.
"""

import argparse
import json
import os
import pickle
import time
from multiprocessing import Pool

import numpy as np
from scipy.optimize import minimize

# ---------------------------------------------------------------------------
# 0. Global settings
# ---------------------------------------------------------------------------
TS = 900.0                      # sampling time [s] (15 min)
STEPS_PER_DAY = int(86400 / TS)
FIG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "FIG")

# Operational constraints (Table 2 of the paper)
T_MIN, T_MAX = 15.0, 25.0       # indoor temperature [degC]
RH_MAX = 70.0                   # relative humidity [%]
CO2_MAX = 1.6                   # CO2 [ppm x 1e-3]
U_MIN = np.array([0.0, 0.0, 0.0])
U_MAX = np.array([1.2, 7.5, 150.0])     # CO2 [mg m-2 s-1], vent [mm s-1], heat [W m-2]
DU_MAX = np.array([0.12, 0.75, 15.0])   # slew-rate limits per sample

# Economic data
C_CO2 = 0.20                    # CO2 price [EUR/kg]
C_DW = 22.0                     # lettuce value [EUR/kg dry weight]


def heat_price(hour):
    """Time-of-use price of heat [EUR/kWh]: night, shoulder and evening peak."""
    hour = np.asarray(hour) % 24.0
    price = np.where((hour >= 6.0) & (hour < 22.0), 0.10, 0.06)
    price = np.where((hour >= 16.0) & (hour < 20.0), 0.15, price)
    return price


# ---------------------------------------------------------------------------
# 1. Van Henten lettuce greenhouse model
# ---------------------------------------------------------------------------
P_TRUE = dict(
    p1=0.544, p2=2.65e-7, p3=53.0, p4=3.55e-9, p5=5.11e-6, p6=2.3e-4,
    p7=6.29e-4, p8=5.2e-5, p9=4.1, p10=4.87e-7, p11=7.5e-6, p12=8.31,
    p13=273.15, p14=101325.0, p15=0.044, p16=3.0e4, p17=1290.0, p18=6.1,
    p19=0.2, p20=4.1, p21=3.6e-3, p22=9348.0, p23=8314.0, p24=273.15,
    p25=17.4, p26=239.0)

# Physics prior used by the model-based controllers: same structure, but six
# parameters are mis-calibrated as they would be after a coarse identification
# (cover heat transmission, solar heat load, ventilation heat/vapour exchange,
# leakage, transpiration, light-use efficiency).
P_NOM = dict(P_TRUE)
P_NOM.update(p18=4.7, p19=0.24, p17=1050.0, p11=1.1e-5, p21=2.6e-3, p4=3.9e-9)


def sat_vap(T, p):
    """Saturation water-vapour density [kg m-3] used by the model."""
    return p["p22"] / (p["p23"] * (T + p["p24"])) * np.exp(p["p25"] * T / (T + p["p26"]))


def rhs(x, u, d, p):
    """Continuous-time right-hand side, vectorised over leading dimensions.

    x = (dry weight [kg m-2], CO2 [kg m-3], temperature [degC], humidity [kg m-3])
    u = (CO2 supply [mg m-2 s-1], ventilation [mm s-1], heating [W m-2])
    d = (radiation [W m-2], CO2 out [kg m-3], temperature out [degC], humidity out [kg m-3])
    """
    x1, x2, x3, x4 = x[..., 0], x[..., 1], x[..., 2], x[..., 3]
    u1, u2, u3 = u[..., 0], u[..., 1], u[..., 2]
    d1, d2, d3, d4 = d[..., 0], d[..., 1], d[..., 2], d[..., 3]
    canopy = 1.0 - np.exp(-p["p3"] * x1)
    a = p["p4"] * d1
    b = (-p["p5"] * x3 ** 2 + p["p6"] * x3 - p["p7"]) * (x2 - p["p8"])
    b = np.maximum(b, 0.0)
    phot = canopy * a * b / (a + b + 1e-20)               # gross canopy photosynthesis
    resp = 2.0 ** ((x3 - 25.0) / 10.0)                    # respiration factor
    vent = u2 * 1e-3 + p["p11"]                           # ventilation + leakage
    out = np.empty(x.shape)
    out[..., 0] = p["p1"] * phot - p["p2"] * x1 * resp
    out[..., 1] = (-phot + p["p10"] * x1 * resp + 1e-6 * u1 - vent * (x2 - d2)) / p["p9"]
    out[..., 2] = (u3 - (p["p17"] * u2 * 1e-3 + p["p18"]) * (x3 - d3) + p["p19"] * d1) / p["p16"]
    transp = p["p21"] * canopy * (sat_vap(x3, p) - x4)    # canopy transpiration
    out[..., 3] = (transp - vent * (x4 - d4)) / p["p20"]
    return out


def rk4_step(x, u, d, p, n_sub):
    """One sampling interval with zero-order-hold inputs and weather."""
    h = TS / n_sub
    for _ in range(n_sub):
        k1 = rhs(x, u, d, p)
        k2 = rhs(x + 0.5 * h * k1, u, d, p)
        k3 = rhs(x + 0.5 * h * k2, u, d, p)
        k4 = rhs(x + h * k3, u, d, p)
        x = x + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
    return x


def plant_step(x, u, d):
    return rk4_step(x, u, d, P_TRUE, 6)


def prior_step(x, u, d):
    return rk4_step(x, u, d, P_NOM, 1)


def outputs(x, p=P_TRUE):
    """Measured outputs: dry weight [g m-2], CO2 [ppm x 1e-3], T [degC], RH [%]."""
    x1, x2, x3, x4 = x[..., 0], x[..., 1], x[..., 2], x[..., 3]
    y1 = 1e3 * x1
    y2 = 1e3 * x2 * p["p12"] * (x3 + p["p13"]) / (p["p14"] * p["p15"])
    y3 = x3
    y4 = 1e2 * x4 / sat_vap(x3, p)
    return np.stack([y1, y2, y3, y4], axis=-1)


def co2_ppm_to_kg(ppm_e3, T, p=P_TRUE):
    return ppm_e3 * 1e-3 * p["p14"] * p["p15"] / (p["p12"] * (T + p["p13"]))


# ---------------------------------------------------------------------------
# 2. Weather, forecasts and noise
# ---------------------------------------------------------------------------
def smooth_noise(rng, n, rho, std):
    e = np.zeros(n)
    for k in range(1, n):
        e[k] = rho * e[k - 1] + np.sqrt(1 - rho ** 2) * std * rng.standard_normal()
    return e


def make_weather(season, n_steps, seed):
    """Synthetic outdoor climate at 15-min resolution (latitude ~55 N).

    Returns array (n_steps, 4): radiation, CO2 [kg m-3], temperature, abs. humidity.
    """
    rng = np.random.default_rng(seed)
    n_req = n_steps
    n_steps = max(n_steps, 10 * STEPS_PER_DAY)       # same realisation for any length
    t_h = np.arange(n_steps) * TS / 3600.0
    hour = t_h % 24.0
    day = (t_h // 24).astype(int)
    n_days = day[-1] + 1
    if season == "summer":
        sunrise, sunset, peak = 4.6, 21.7, 700.0
        cloud_day = np.clip(rng.uniform(0.45, 1.0, n_days), 0, 1)
        t_mean = 14.5 + rng.normal(0, 1.5, n_days)
        t_mean[2] -= 4.0                    # cool, overcast day
        t_mean[4] += 3.5                    # warm spell
        cloud_day[2] = 0.35
        t_amp = 5.0
        rh_night, rh_day = 0.90, 0.62
    else:
        sunrise, sunset, peak = 8.6, 15.9, 230.0
        cloud_day = np.clip(rng.uniform(0.3, 1.0, n_days), 0, 1)
        t_mean = 3.0 + rng.normal(0, 1.5, n_days)
        t_mean[3] -= 6.0                    # cold snap
        t_mean[4] -= 4.0
        t_amp = 3.0
        rh_night, rh_day = 0.92, 0.80
    daylen = sunset - sunrise
    s = np.clip((hour - sunrise) / daylen, 0, 1)
    clear = peak * np.sin(np.pi * s) ** 1.5
    passing = np.clip(1.0 + smooth_noise(rng, n_steps, 0.8, 0.18), 0.25, 1.15)
    rad = np.clip(clear * cloud_day[day] * passing, 0, None)
    # smooth day-to-day mean temperature, diurnal cycle peaking at 15 h
    tm = np.interp(t_h, np.arange(n_days) * 24 + 12, t_mean)
    temp = tm + t_amp * np.cos(2 * np.pi * (hour - 15.0) / 24.0) \
        + smooth_noise(rng, n_steps, 0.95, 0.6)
    # relative humidity high at night, low in the afternoon
    w = 0.5 * (1 + np.cos(2 * np.pi * (hour - 15.0) / 24.0))
    rh = np.clip(rh_night * (1 - w) + rh_day * w + smooth_noise(rng, n_steps, 0.95, 0.04), 0.3, 0.99)
    hum = rh * sat_vap(temp, P_TRUE)
    co2 = co2_ppm_to_kg(0.41 + smooth_noise(rng, n_steps, 0.98, 0.01), temp)
    return np.stack([rad, co2, temp, hum], axis=1)[:n_req]


def forecast(weather, k, horizon, seed):
    """Weather forecast issued at time k for k..k+horizon-1.

    The first element is the measurement; later elements carry errors that
    grow with lead time (temperature bias random walk, multiplicative cloud
    error on radiation, humidity error).
    """
    n = weather.shape[0]
    idx = np.minimum(np.arange(k, k + horizon), n - 1)
    fc = weather[idx].copy()
    rng = np.random.default_rng(seed + 7919 * k)
    lead = np.arange(horizon)
    t_err = np.cumsum(np.r_[0.0, 0.18 * rng.standard_normal(horizon - 1)])
    r_err = np.cumsum(np.r_[0.0, 0.05 * rng.standard_normal(horizon - 1)])
    h_err = np.cumsum(np.r_[0.0, 0.015 * rng.standard_normal(horizon - 1)])
    fc[:, 2] += t_err
    fc[:, 0] = np.clip(fc[:, 0] * (1 + r_err), 0, None)
    fc[:, 3] = fc[:, 3] * np.clip(1 + h_err, 0.6, 1.4)
    fc[lead == 0] = weather[min(k, n - 1)]
    return fc


W_STD = np.array([0.0, 4e-7, 0.08, 1.5e-5])     # process noise std per step
W_BAR = 2.5 * W_STD                               # bound (truncation at 2.5 sigma)


def process_noise(rng):
    return np.clip(W_STD * rng.standard_normal(4), -W_BAR, W_BAR)


# ---------------------------------------------------------------------------
# 3. Kernel recursive least squares with ALD novelty and posterior variance
# ---------------------------------------------------------------------------
# Regressor z = (CO2, T, humidity, u1, u2, u3, radiation, T_out, hum_out),
# normalised by fixed operating ranges so that a single isotropic Gaussian
# kernel with unit diagonal can be used.
Z_LO = np.array([3e-4, 5.0, 3e-3, 0.0, 0.0, 0.0, 0.0, -10.0, 1e-3])
Z_HI = np.array([3e-3, 32.0, 2.2e-2, 1.2, 7.5, 150.0, 900.0, 30.0, 1.6e-2])
RES_SCALE = np.array([2e-5, 0.4, 3e-4])          # residual scaling (CO2, T, hum)


def regressor(x, u, d):
    z = np.concatenate([x[..., 1:4], u, d[..., [0, 2, 3]]], axis=-1)
    return (z - Z_LO) / (Z_HI - Z_LO)


class KRLS:
    """Sparse kernel ridge regression computed recursively (KRLS-ALD).

    Model:      g_hat(z) = k(z)^T alpha,   alpha = (K + lam I)^{-1} Y
    Variance:   sigma^2(z) = 1 - k(z)^T (K + lam I)^{-1} k(z)
    Novelty:    a sample is added when sigma^2(z) > nu (ALD test).
    """

    def __init__(self, ell=0.5, lam=0.01, nu=0.012, m_max=600, n_out=3):
        self.ell, self.lam, self.nu, self.m_max = ell, lam, nu, m_max
        self.Z = np.zeros((0, len(Z_LO)))
        self.Y = np.zeros((0, n_out))
        self.P = np.zeros((0, 0))
        self.alpha = np.zeros((0, n_out))
        self.version = 0

    def kern(self, A, B):
        d2 = (np.sum(A ** 2, -1)[..., None] + np.sum(B ** 2, -1)[None, :]
              - 2.0 * A @ B.T)
        return np.exp(-0.5 * np.maximum(d2, 0.0) / self.ell ** 2)

    def predict(self, Zq):
        """Mean (scaled residual) and posterior std at query points (n, dz)."""
        if self.Z.shape[0] == 0:
            return np.zeros((Zq.shape[0], self.Y.shape[1])), np.ones(Zq.shape[0])
        k = self.kern(Zq, self.Z)
        mean = k @ self.alpha
        var = 1.0 - np.sum((k @ self.P) * k, axis=1)
        return mean, np.sqrt(np.clip(var, 0.0, 1.0))

    def update(self, z, y):
        """Process one sample; returns True if the dictionary grew."""
        _, s = self.predict(z[None, :])
        var = s[0] ** 2
        if var <= self.nu or self.Z.shape[0] >= self.m_max:
            return False
        if self.Z.shape[0] == 0:
            self.P = np.array([[1.0 / (1.0 + self.lam)]])
        else:
            b = self.kern(z[None, :], self.Z)[0]
            Pb = self.P @ b
            delta = var + self.lam           # Schur complement of K + lam I
            m = self.P.shape[0]
            Pn = np.empty((m + 1, m + 1))
            Pn[:m, :m] = self.P + np.outer(Pb, Pb) / delta
            Pn[:m, m] = -Pb / delta
            Pn[m, :m] = -Pb / delta
            Pn[m, m] = 1.0 / delta
            self.P = Pn
        self.Z = np.vstack([self.Z, z])
        self.Y = np.vstack([self.Y, y])
        self.alpha = self.P @ self.Y
        self.version += 1
        return True

    def snapshot(self):
        s = KRLS(self.ell, self.lam, self.nu, self.m_max, self.Y.shape[1])
        s.Z, s.Y, s.P, s.alpha, s.version = self.Z, self.Y, self.P, self.alpha, self.version
        return s


# ---------------------------------------------------------------------------
# 4. Base (rule-based) policy kappa and the rule-based controller
# ---------------------------------------------------------------------------
def kappa(x, d, u_prev, T_sp=16.5):
    """Static zone-keeping feedback used as base policy in the finite tail.

    Heating: model-based feed-forward plus proportional action on T.
    Ventilation: proportional on temperature above 22 C and on RH above 60 %.
    CO2: dosing towards 0.9e3 ppm while radiation is available and vents are
    nearly closed. The output is projected on the box and slew-rate limits.
    """
    y = outputs(x, P_NOM)
    T, rh, co2 = y[..., 2], y[..., 3], y[..., 1]
    T_sp = T_sp + 0.25 * np.maximum(rh - 66.0, 0.0)       # dehumidification heating
    u2 = 1.5 * np.maximum(T - 22.0, 0.0) + 0.5 * np.maximum(rh - 60.0, 0.0)
    u2 = np.clip(u2, 0.0, 7.5)
    ff = (P_NOM["p18"] + P_NOM["p17"] * 1e-3 * u2) * (T_sp - d[..., 2]) - P_NOM["p19"] * d[..., 0]
    u3 = ff + 30.0 * (T_sp - T)
    light = np.clip((d[..., 0] - 40.0) / 40.0, 0.0, 1.0)
    u1 = 1.2 * light * np.clip((0.9 - co2) / 0.3, 0, 1) * np.clip(2.0 - u2, 0, 1)
    u = np.stack([u1, u2, u3], axis=-1)
    u = np.clip(u, u_prev - DU_MAX, u_prev + DU_MAX)
    return np.clip(u, U_MIN, U_MAX)


class RuleBased:
    name = "RB"

    def __init__(self):
        self.integ = 0.0

    def __call__(self, k, x_meas, u_prev, wx, seed):
        d = wx[k]
        y = outputs(x_meas, P_NOM)
        T_sp = 16.5
        # conditional integration (anti-windup): integrate only near the set-point
        if y[2] < T_sp + 1.5:
            self.integ = np.clip(self.integ + 0.2 * (T_sp - y[2]), 0.0, 60.0)
        else:
            self.integ *= 0.8
        u = kappa(x_meas, d, u_prev, T_sp)
        u = u.copy()
        u[2] = np.clip(u[2] + self.integ, max(0.0, u_prev[2] - DU_MAX[2]),
                       min(U_MAX[2], u_prev[2] + DU_MAX[2]))
        return u, {}


# ---------------------------------------------------------------------------
# 5. Economic MPC (nominal NMPC and KA-EMPC share this class)
# ---------------------------------------------------------------------------
BLOCKS = [1, 1, 2, 4, 4]            # move blocking over N = 12 steps (3 h)
N_HOR = sum(BLOCKS)
M_TAIL = 12                         # finite-tail rollout length (3 h)

# Exact-penalty weights [EUR per unit violation per step] (linear + quadratic)
PEN_T = (0.02, 0.02)
PEN_RH = (0.008, 0.004)
PEN_C = (0.02, 0.02)
W_DU = np.array([2e-5, 2e-5, 2e-5])  # smoothness weight on normalised moves
CONTRACT = np.array([0.99, 0.83, 0.87])  # per-step contraction of (CO2, T, hum)


def soft_plus(v, eps=0.02):
    return 0.5 * (v + np.sqrt(v * v + eps * eps))


class EconomicMPC:
    """Economic MPC with optional KRLS residual, tightening and finite tail.

    learn=False, beta=0, tail=0  -> nominal economic NMPC on the prior f0
    learn=True,  beta>0, tail=M  -> KA-EMPC
    """

    def __init__(self, learn, beta, tail, name, krls_kw=None, bias=False):
        self.learn, self.beta, self.tail, self.name = learn, beta, tail, name
        self.bias = bias                 # offset-free correction (nominal NMPC)
        self.b_hat = np.zeros(4)
        self.krls = KRLS(**(krls_kw or {})) if learn else None
        self.model = self.krls.snapshot() if learn else None
        self.prev_sol = None
        self.n_reject = 0
        self.n_switch = 0
        self.n_switch_fallback = 0    # switches made because the old candidate was infeasible
        self.last_z = None
        self.last_x = None
        self.last_u = None

    # -- prediction ---------------------------------------------------------
    def rollout(self, x0, U, fc, u_prev, model, base=False):
        """Batched prediction. U: (B, N, 3). Returns stage costs and logs.

        With base=True the base policy pi is applied over the whole horizon
        and the inputs it generates are written back into U (used to build
        the base-policy candidate plan)."""
        B = U.shape[0]
        H = N_HOR + self.tail
        x = np.repeat(x0[None, :], B, axis=0)
        r = np.zeros((B, 3))                          # tube radii (CO2, T, hum)
        var = np.zeros((B, 3))                        # propagated error variance
        up = np.repeat(u_prev[None, :], B, axis=0)
        hours = fc["hour"]
        cost = np.zeros(B)
        pen_total = np.zeros(B)
        vmax = np.full(B, -np.inf)                    # largest tightened-constraint violation
        vmax_nohi = np.full(B, -np.inf)               # same, without the upper temperature bound
        vparts = np.full((2, 4, B), -np.inf)          # per constraint (lo, hi, rh, co2): free moves / tail
        X = np.zeros((B, H + 1, 4))
        R = np.zeros((B, H + 1, 3))
        X[:, 0] = x
        for i in range(H):
            d = np.repeat(fc["d"][i][None, :], B, axis=0)
            if i < N_HOR and not base:
                u = U[:, i]
            else:
                u = kappa(x, d, up)
                if i < N_HOR:
                    U[:, i] = u
            xn = prior_step(x, u, d)
            if self.bias:
                xn = xn + self.b_hat
            if model is not None:
                z = regressor(x, u, d)
                mu, sig = model.predict(z)
                xn = xn.copy()
                xn[:, 1:4] += mu * RES_SCALE
                if self.beta > 0:
                    # covariance propagation of the prediction error (diagonal,
                    # contraction factors of the climate states); the margin is
                    # beta times the propagated standard deviation
                    var = CONTRACT ** 2 * var + (sig[:, None] * RES_SCALE) ** 2 + W_STD[1:4] ** 2
                    r = self.beta * np.sqrt(var)
            xn[:, 1] = np.maximum(xn[:, 1], 1e-5)
            xn[:, 3] = np.maximum(xn[:, 3], 1e-4)
            # economic stage cost
            c_heat = heat_price(hours[i]) * u[:, 2] * TS / 3.6e6
            c_co2 = C_CO2 * u[:, 0] * 1e-6 * TS
            growth = C_DW * (xn[:, 0] - x[:, 0])
            du = (u - up) / DU_MAX
            cost += c_heat + c_co2 - growth + np.sum(W_DU * du ** 2, axis=1)
            # tightened output constraints, smoothed exact-type penalty
            y = outputs(xn, P_NOM)
            sat = sat_vap(xn[:, 2], P_NOM)
            rT = r[:, 1]
            rRH = 100.0 * r[:, 2] / sat
            rC = 1e3 * r[:, 0] * P_NOM["p12"] * (xn[:, 2] + P_NOM["p13"]) / (P_NOM["p14"] * P_NOM["p15"])
            g_lo = T_MIN + rT - y[:, 2]                     # <= 0 when satisfied [K]
            g_hi = y[:, 2] + rT - T_MAX                     # [K]
            g_rh = y[:, 3] + rRH - RH_MAX                   # [% RH]
            g_c = y[:, 1] + rC - CO2_MAX                    # [ppm x 1e-3]
            # hard check of the tightened constraints (used for the
            # accept-if-feasible switch and the feasibility diagnostic)
            vmax = np.maximum(vmax, np.max(np.stack([g_lo, g_hi, g_rh, g_c]), axis=0))
            vmax_nohi = np.maximum(vmax_nohi, np.max(np.stack([g_lo, g_rh, g_c]), axis=0))
            seg = 0 if i < N_HOR else 1
            vparts[seg] = np.maximum(vparts[seg], np.stack([g_lo, g_hi, g_rh, g_c]))
            vlo, vhi, vrh, vc = soft_plus(g_lo), soft_plus(g_hi), soft_plus(g_rh), soft_plus(g_c)
            pen = (PEN_T[0] * (vlo + vhi) + PEN_T[1] * (vlo ** 2 + vhi ** 2)
                   + PEN_RH[0] * vrh + PEN_RH[1] * vrh ** 2
                   + PEN_C[0] * vc + PEN_C[1] * vc ** 2)
            cost += pen
            pen_total += pen
            x, up = xn, u
            X[:, i + 1] = x
            R[:, i + 1] = r
        self.last_vmax = vmax
        self.last_vmax_nohi = vmax_nohi
        self.last_vparts = vparts
        return cost, pen_total, X, R

    def expand(self, v):
        """Decision vector (blocks*3, normalised) -> input trajectory (N, 3)."""
        mv = v.reshape(-1, len(BLOCKS), 3) * U_MAX
        return np.repeat(mv, BLOCKS, axis=1)

    def solve(self, x0, u_prev, fc, model):
        nv = 3 * len(BLOCKS)
        if self.prev_sol is None:
            v0 = np.tile(np.clip(u_prev, U_MIN, U_MAX) / U_MAX, len(BLOCKS))
        else:
            # shift by one sample: first block takes the second block's move
            mv = self.prev_sol.reshape(len(BLOCKS), 3)
            v0 = np.vstack([mv[1:], mv[-1:]]).ravel()
        h = 1e-4
        scale = 1e3                                   # milli-EUR for conditioning
        v0 = np.clip(v0, 0.0, 1.0)
        # Base-policy candidate: roll pi out on the model and sample it at the
        # start of every block. It is always available (Section 5) and
        # protects the optimizer against a poor warm start.
        Ub = np.zeros((1, N_HOR, 3))
        self.rollout(x0, Ub, fc, u_prev, model, base=True)
        starts = np.concatenate([[0], np.cumsum(BLOCKS)[:-1]])
        mb = Ub[0, starts]
        prev = u_prev.copy()
        for j in range(len(BLOCKS)):                  # respect block slew limits
            mb[j] = np.clip(mb[j], prev - DU_MAX, prev + DU_MAX)
            prev = mb[j]
        vb = np.clip(mb / U_MAX, 0.0, 1.0).ravel()

        fcache, gcache = {}, {}

        def f(v):
            key = v.tobytes()
            if key not in fcache:
                c, _, _, _ = self.rollout(x0, self.expand(v[None, :]), fc, u_prev, model)
                fcache[key] = c[0] * scale
            return fcache[key]

        def g(v):
            # forward differences, all perturbed trajectories in one batch
            key = v.tobytes()
            if key not in gcache:
                V = np.vstack([v, v + h * np.eye(nv)])
                c, _, _, _ = self.rollout(x0, self.expand(V), fc, u_prev, model)
                c = c * scale
                fcache[key] = c[0]
                gcache[key] = (c[1:] - c[0]) / h
            return gcache[key]

        # slew-rate constraints between consecutive moves (normalised)
        A, bvec = [], []
        dun = DU_MAX / U_MAX
        for j in range(len(BLOCKS)):
            for a in range(3):
                row = np.zeros(nv)
                row[3 * j + a] = 1.0
                if j > 0:
                    row[3 * (j - 1) + a] = -1.0
                    off = 0.0
                else:
                    off = u_prev[a] / U_MAX[a]
                A.append(row.copy()); bvec.append(dun[a] + off)
                A.append(-row); bvec.append(dun[a] - off)
        A, bvec = np.array(A), np.array(bvec)
        cons = [{"type": "ineq", "fun": lambda v: bvec - A @ v, "jac": lambda v: -A}]
        lo = np.maximum(0.0, (u_prev - DU_MAX) / U_MAX)
        hi = np.minimum(1.0, (u_prev + DU_MAX) / U_MAX)
        v0[:3] = np.clip(v0[:3], lo, hi)
        if f(vb) < f(v0):                             # start from the better plan
            v0 = vb
        res = minimize(f, v0, jac=g,
                       bounds=[(0.0, 1.0)] * nv, constraints=cons,
                       method="SLSQP", options=dict(maxiter=30, ftol=1e-6))
        v = np.clip(res.x, 0.0, 1.0)
        if not np.isfinite(f(v)) or f(v) > f(v0):     # never return a worse plan
            v = v0
        self.prev_sol = v
        return v

    def candidate_violation(self, x0, u_prev, fc, model):
        """Largest tightened-constraint violation of the shifted candidate
        (Lemma 3); a value <= 0 means the candidate is feasible."""
        if self.prev_sol is None:
            return -1.0
        mv = self.prev_sol.reshape(len(BLOCKS), 3)
        v = np.vstack([mv[1:], mv[-1:]]).ravel()
        self.rollout(x0, self.expand(v[None, :]), fc, u_prev, model)
        return float(self.last_vmax[0])

    def __call__(self, k, x_meas, u_prev, wx, seed):
        H = N_HOR + self.tail
        fcd = forecast(wx, k, H, seed)
        fc = {"d": fcd, "hour": (np.arange(k, k + H) * TS / 3600.0)}
        info = {}
        if self.bias and self.last_x is not None:
            # constant output-disturbance estimate (standard offset-free NMPC)
            b = x_meas - prior_step(self.last_x, self.last_u, self.last_d)
            b[0] = 0.0
            self.b_hat = 0.5 * self.b_hat + 0.5 * b
        if self.learn:
            # learn from the transition (x_{k-1}, u_{k-1}, d_{k-1}) -> x_k
            if self.last_x is not None:
                y = (x_meas[1:4] - prior_step(self.last_x, self.last_u, self.last_d)[1:4]) / RES_SCALE
                pred_old, sig_old = self.model.predict(self.last_z[None, :])
                info["err"] = (y - pred_old[0]) * RES_SCALE
                info["sig_used"] = sig_old[0]
                self.krls.update(self.last_z, y)
            # accept-if-feasible model switching
            if self.krls.version != self.model.version:
                new = self.krls.snapshot()
                v_new = self.candidate_violation(x_meas, u_prev, fc, new)
                v_old = self.candidate_violation(x_meas, u_prev, fc, self.model)
                # Algorithm 1, step 3: switch if the shifted candidate satisfies
                # every tightened constraint with the new model. Implementation
                # fallback (Table 3): also switch when the candidate is infeasible
                # for the current model, because keeping that model then
                # guarantees nothing either.
                if v_new <= 0.0 or v_old > 0.0:
                    self.model = new
                    self.n_switch += 1
                    if v_new > 0.0:
                        # neither candidate is feasible: the implementation
                        # switches anyway (Section 6.5), the analysis would not
                        self.n_switch_fallback += 1
                else:
                    self.n_reject += 1
            info["dict"] = self.krls.Z.shape[0]
        t0 = time.perf_counter()
        v = self.solve(x_meas, u_prev, fc, self.model)
        info["cpu"] = time.perf_counter() - t0
        U = self.expand(v[None, :])
        _, pen, X, R = self.rollout(x_meas, U, fc, u_prev, self.model)
        # largest tightened-constraint violation of the applied plan; <= 0
        # means that the plan satisfies every tightened constraint of the
        # implemented problem over the whole horizon
        info["pen"] = float(self.last_vmax[0])
        info["pen2"] = float(self.last_vmax_nohi[0])
        info["vparts"] = self.last_vparts[:, :, 0].copy()
        info["tube_T"] = R[0, 1:, 1]
        info["pred_T"] = X[0, 1:, 2]
        u = U[0, 0]
        self.last_x, self.last_u, self.last_d = x_meas.copy(), u.copy(), wx[k].copy()
        if self.learn:
            d = wx[k]
            self.last_z = regressor(x_meas, u, d)
            _, s = self.model.predict(self.last_z[None, :])
            info["sigma"] = s[0]
        return u, info


# ---------------------------------------------------------------------------
# 6. Closed-loop simulation and metrics
# ---------------------------------------------------------------------------
X0 = {"summer": np.array([0.008, 0.0008, 18.0, 0.0085]),     # 65 % RH
      "winter": np.array([0.008, 0.0008, 17.0, 0.0078])}     # 63 % RH


def warm_start_data(season, seed):
    """Two days of historical operation under the rule-based controller.

    Used to initialise the KRLS dictionary of KA-EMPC; the weather of this
    period is a different realisation from the evaluation period.
    """
    n = 2 * STEPS_PER_DAY
    wx = make_weather(season, n + 8, seed + 101)
    rng = np.random.default_rng(seed + 5)
    x = X0[season].copy()
    u_prev = np.array([0.0, 0.0, 50.0])
    rb = RuleBased()
    data = []
    for k in range(n):
        u, _ = rb(k, x, u_prev, wx, seed)
        # small excitation added to the historical inputs
        u = np.clip(u + np.array([0.05, 0.3, 4.0]) * rng.standard_normal(3), U_MIN, U_MAX)
        xn = plant_step(x, u, wx[k]) + process_noise(rng)
        y = (xn[1:4] - prior_step(x, u, wx[k])[1:4]) / RES_SCALE
        data.append((regressor(x, u, wx[k]), y))
        x, u_prev = xn, u
    return data


def simulate(ctrl_name, season, days, beta=2.0, seed=1):
    n = days * STEPS_PER_DAY
    wx = make_weather(season, n + N_HOR + M_TAIL + 2, seed)
    rng = np.random.default_rng(seed + 1000)
    if ctrl_name == "RB":
        ctrl = RuleBased()
    elif ctrl_name == "NMPC":
        ctrl = EconomicMPC(learn=False, beta=0.0, tail=0, name="NMPC", bias=True)
    else:
        ctrl = EconomicMPC(learn=True, beta=beta, tail=M_TAIL, name=ctrl_name)
        for z, y in warm_start_data(season, seed):
            ctrl.krls.update(z, y)
        ctrl.model = ctrl.krls.snapshot()
    x = X0[season].copy()
    u_prev = np.array([0.0, 0.0, 50.0])
    log = {k: [] for k in ["x", "y", "u", "cpu", "sigma", "err", "sig_used", "dict",
                           "pen", "pen2", "vparts", "tube_T", "pred_T"]}
    for k in range(n):
        x_meas = x.copy()
        u, info = ctrl(k, x_meas, u_prev, wx, seed)
        u = np.clip(u, np.maximum(U_MIN, u_prev - DU_MAX), np.minimum(U_MAX, u_prev + DU_MAX))
        log["x"].append(x.copy())
        log["y"].append(outputs(x))
        log["u"].append(u.copy())
        for key in ["cpu", "sigma", "err", "sig_used", "dict", "pen", "pen2", "vparts"]:
            if key in info:
                log[key].append(info[key])
        if k in (STEPS_PER_DAY * 1 + 8, STEPS_PER_DAY * 3 + 8) and "tube_T" in info:
            log["tube_T"].append(info["tube_T"])
            log["pred_T"].append(info["pred_T"])
        x = plant_step(x, u, wx[k]) + process_noise(rng)
        x[1] = max(x[1], 1e-5)
        u_prev = u
    out = {k: np.array(v) for k, v in log.items() if len(v) > 0}
    out["weather"] = wx[:n]
    out["x_end"] = x
    if hasattr(ctrl, "n_switch"):
        out["n_switch"] = ctrl.n_switch
        out["n_reject"] = ctrl.n_reject
        out["n_switch_fallback"] = ctrl.n_switch_fallback
    return out


def runs(mask):
    """Lengths of consecutive True runs."""
    lens, c = [], 0
    for m in mask:
        if m:
            c += 1
        elif c:
            lens.append(c); c = 0
    if c:
        lens.append(c)
    return lens


def metrics(res):
    y, u = res["y"], res["u"]
    n = len(y)
    out = {}
    for key, viol in [("Tlo", T_MIN - y[:, 2]), ("Thi", y[:, 2] - T_MAX),
                      ("RH", y[:, 3] - RH_MAX), ("CO2", y[:, 1] - CO2_MAX)]:
        mask = viol > 1e-9
        r = runs(mask)
        out[key] = dict(rate=100.0 * mask.mean(),
                        avg_period=float(np.mean(r)) if r else 0.0,
                        max_period=int(max(r)) if r else 0,
                        max_size=float(viol.max()) if mask.any() else 0.0,
                        integral=float(np.sum(np.maximum(viol, 0)) * TS / 3600.0))
    hours = np.arange(n) * TS / 3600.0
    heat_kwh = u[:, 2] * TS / 3.6e6
    out["heat_kWh"] = float(heat_kwh.sum())
    out["heat_EUR"] = float(np.sum(heat_kwh * heat_price(hours)))
    out["co2_kg"] = float(np.sum(u[:, 0] * 1e-6 * TS))
    out["co2_EUR"] = C_CO2 * out["co2_kg"]
    out["dw_gain_g"] = float(1e3 * (res["x_end"][0] - res["x"][0, 0]))
    out["revenue_EUR"] = C_DW * out["dw_gain_g"] / 1e3
    out["profit_EUR"] = out["revenue_EUR"] - out["heat_EUR"] - out["co2_EUR"]
    du = np.diff(u, axis=0) / DU_MAX
    out["smooth_TV"] = [float(np.mean(np.abs(du[:, a]))) for a in range(3)]
    out["smooth_RMS"] = float(np.sqrt(np.mean(du ** 2)))
    out["vent_mean"] = float(u[:, 1].mean())
    if "pen" in res:
        # share of samples whose applied plan met every (tightened) constraint
        out["feas_share"] = float(np.mean(res["pen"] <= 0.0))
        # the upper temperature bound is physically unattainable on warm days
        # (no cooling), so feasibility is also reported without it
        out["feas_share_nohi"] = float(np.mean(res["pen2"] <= 0.0))
    if "vparts" in res:
        # which constraint makes the plan infeasible, and where: vparts has
        # shape (samples, 2 segments [free moves, tail], 4 constraints
        # [T_min, T_max, RH, CO2])
        vp = res["vparts"]
        inf = res["pen2"] > 0.0                         # infeasible without T_max
        if inf.any():
            rh = vp[inf, :, 2].max(axis=1) > 0.0
            out["inf_rh_share"] = float(np.mean(rh))   # humidity bound violated
            only_tail = (vp[inf, 1, :].max(axis=1) > 0.0) & ~(vp[inf, 0][:, [0, 2, 3]].max(axis=1) > 0.0)
            out["inf_tail_share"] = float(np.mean(only_tail))  # violated only in the tail
        else:
            out["inf_rh_share"] = out["inf_tail_share"] = 0.0
    if "cpu" in res:
        out["cpu_mean"] = float(res["cpu"].mean())
        out["cpu_max"] = float(res["cpu"].max())
    if "err" in res and len(res["err"]) > 0:
        err = res["err"]
        sig = res["sig_used"]
        bound = 2.0 * sig[:, None] * RES_SCALE + W_BAR[1:4]
        out["cover_beta2"] = [float(np.mean(np.abs(err[:, a]) <= bound[:, a])) for a in range(3)]
        out["rmse_T"] = float(np.sqrt(np.mean(err[:, 1] ** 2)))
        out["dict_final"] = int(res["dict"][-1])
        out["sigma_mean"] = float(res["sigma"].mean())
        out["n_switch"] = int(res.get("n_switch", 0))
        out["n_reject"] = int(res.get("n_reject", 0))
        out["n_switch_fallback"] = int(res.get("n_switch_fallback", 0))
    return out


def prior_error(season, days, seed=1):
    """One-step error of the physics prior alone along the RB closed loop."""
    res = simulate("RB", season, days, seed=seed)
    x, u, wx = res["x"], res["u"], res["weather"]
    e = x[1:, 1:4] - np.array([prior_step(x[k], u[k], wx[k])[1:4] for k in range(len(x) - 1)])
    return float(np.sqrt(np.mean(e[:, 1] ** 2)))


# ---------------------------------------------------------------------------
# 7. Figures
# ---------------------------------------------------------------------------
def setup_mpl():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "serif", "font.size": 8, "axes.labelsize": 8,
        "axes.titlesize": 8, "legend.fontsize": 7, "xtick.labelsize": 7,
        "ytick.labelsize": 7, "lines.linewidth": 0.9, "axes.grid": True,
        "grid.alpha": 0.3, "grid.linewidth": 0.4, "savefig.bbox": "tight",
        "savefig.pad_inches": 0.02, "pdf.fonttype": 42})
    return plt


COL = {"RB": "#7f7f7f", "NMPC": "#d62728", "KA-EMPC": "#1f77b4"}
LAB = {"RB": "Rule-based", "NMPC": "Nominal NMPC", "KA-EMPC": "KA-EMPC"}


def fig_weather(plt, R, days):
    fig, ax = plt.subplots(3, 2, figsize=(7.16, 2.3), sharex="col")
    for j, s in enumerate(["summer", "winter"]):
        w = R[s]["RB"]["weather"]
        t = np.arange(len(w)) * TS / 86400.0
        ax[0, j].plot(t, w[:, 0], color="#ff7f0e")
        ax[1, j].plot(t, w[:, 2], color="#2ca02c")
        rh = 100 * w[:, 3] / sat_vap(w[:, 2], P_TRUE)
        ax[2, j].plot(t, rh, color="#9467bd")
        ax[0, j].set_title("Summer scenario" if s == "summer" else "Winter scenario")
        ax[2, j].set_xlabel("Time [days]")
        ax[2, j].set_xlim(0, days)
    ax[0, 0].set_ylabel("$d_1$ [W m$^{-2}$]")
    ax[1, 0].set_ylabel("$d_3$ [$^\\circ$C]")
    ax[2, 0].set_ylabel("RH$_{\\rm out}$ [%]")
    fig.align_ylabels(ax[:, 0])
    fig.savefig(os.path.join(FIG_DIR, "fig_weather.pdf"))
    plt.close(fig)


def fig_outputs(plt, R, days):
    """Climate outputs and dry weight, summer (left) and winter (right)."""
    fig, ax = plt.subplots(4, 2, figsize=(7.16, 4.0), sharex="col")
    for j, season in enumerate(["summer", "winter"]):
        for c in ["RB", "NMPC", "KA-EMPC"]:
            y = R[season][c]["y"]
            t = np.arange(len(y)) * TS / 86400.0
            lw = 0.9 if c == "KA-EMPC" else 0.6
            ax[0, j].plot(t, y[:, 2], color=COL[c], lw=lw, label=LAB[c])
            ax[1, j].plot(t, y[:, 3], color=COL[c], lw=lw)
            ax[2, j].plot(t, 1e3 * y[:, 1], color=COL[c], lw=lw)
            ax[3, j].plot(t, y[:, 0], color=COL[c], lw=lw)
        for v in (T_MIN, T_MAX):
            ax[0, j].axhline(v, color="k", ls="--", lw=0.6)
        ax[1, j].axhline(RH_MAX, color="k", ls="--", lw=0.6)
        ax[0, j].set_title("Summer scenario" if season == "summer" else "Winter scenario")
        ax[3, j].set_xlabel("Time [days]")
        ax[3, j].set_xlim(0, days)
    ax[0, 0].set_ylabel("$y_3$ [$^\\circ$C]")
    ax[1, 0].set_ylabel("$y_4$ [%]")
    ax[2, 0].set_ylabel("$y_2$ [ppm]")
    ax[3, 0].set_ylabel("$y_1$ [g m$^{-2}$]")
    ax[0, 1].legend(ncol=3, loc="upper right", fontsize=6, framealpha=0.9)
    fig.align_ylabels(ax[:, 0])
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG_DIR, "fig_outputs.pdf"))
    plt.close(fig)


def fig_inputs(plt, R, days):
    fig, ax = plt.subplots(3, 2, figsize=(7.16, 2.9), sharex="col")
    for j, season in enumerate(["summer", "winter"]):
        for c in ["RB", "NMPC", "KA-EMPC"]:
            u = R[season][c]["u"]
            t = np.arange(len(u)) * TS / 86400.0
            lw = 0.9 if c == "KA-EMPC" else 0.6
            for a in range(3):
                ax[a, j].plot(t, u[:, a], color=COL[c], lw=lw, label=LAB[c], drawstyle="steps-post")
        ax[0, j].set_title("Summer scenario" if season == "summer" else "Winter scenario")
        ax[2, j].set_xlabel("Time [days]")
        ax[2, j].set_xlim(0, days)
    ax[0, 0].set_ylabel("$u_1$ [mg m$^{-2}$s$^{-1}$]")
    ax[1, 0].set_ylabel("$u_2$ [mm s$^{-1}$]")
    ax[2, 0].set_ylabel("$u_3$ [W m$^{-2}$]")
    ax[0, 1].legend(ncol=3, loc="upper right", fontsize=6, framealpha=0.9)
    fig.align_ylabels(ax[:, 0])
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG_DIR, "fig_inputs.pdf"))
    plt.close(fig)


def fig_learning(plt, R, days):
    fig, ax = plt.subplots(2, 2, figsize=(7.16, 2.5))
    for j, s in enumerate(["summer", "winter"]):
        r = R[s]["KA-EMPC"]
        err, sig = r["err"], r["sig_used"]
        t = np.arange(1, len(err) + 1) * TS / 86400.0
        bound = 2.0 * sig * RES_SCALE[1] + W_BAR[2]
        ax[0, j].fill_between(t, -bound, bound, color=COL["KA-EMPC"], alpha=0.25, lw=0,
                              label="bound $\\pm(\\beta\\sigma_k s_T+\\bar w_T)$, $\\beta=2$")
        ax[0, j].plot(t, err[:, 1], color="k", lw=0.5, label="one-step error, KA model")
        ax[0, j].set_ylabel("$e_T$ [$^\\circ$C]")
        ax[0, j].set_title("Summer scenario" if s == "summer" else "Winter scenario")
        ax2 = ax[1, j]
        ax2.plot(np.arange(len(r["sigma"])) * TS / 86400.0, r["sigma"], color=COL["KA-EMPC"], lw=0.6)
        ax2.set_ylabel("$\\sigma_k(z_k)$")
        ax2.set_xlabel("Time [days]")
        ax3 = ax2.twinx()
        ax3.plot(np.arange(len(r["dict"])) * TS / 86400.0, r["dict"], color="#ff7f0e", lw=1.0)
        ax3.set_ylabel("$m_k$", color="#ff7f0e")
        ax3.grid(False)
        ax[0, j].set_xlim(0, days)
        ax2.set_xlim(0, days)
    ax[0, 0].legend(loc="lower right", fontsize=6, framealpha=0.9)
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG_DIR, "fig_learning.pdf"))
    plt.close(fig)


def fig_tube(plt, R):
    r = R["winter"]["KA-EMPC"]
    if "tube_T" not in r or len(r["tube_T"]) < 2:
        return
    fig, ax = plt.subplots(1, 2, figsize=(3.5, 1.9), sharey=True)
    for j in range(2):
        pT, tT = r["pred_T"][j], r["tube_T"][j]
        i = np.arange(1, len(pT) + 1)
        ax[j].fill_between(i, pT - tT, pT + tT, color=COL["KA-EMPC"], alpha=0.25, lw=0,
                           label="tube $\\hat y_3\\pm r_{i|k}$")
        ax[j].plot(i, pT, color=COL["KA-EMPC"], label="predicted $\\hat y_3$")
        ax[j].axhline(T_MIN, color="k", ls="--", lw=0.6)
        ax[j].axvline(N_HOR + 0.5, color="k", lw=0.5, ls=":")
        ax[j].text(N_HOR + 0.8, ax[j].get_ylim()[0] if False else T_MIN - 0.6, "tail", fontsize=7)
        ax[j].set_xlabel("Prediction step $i$")
        ax[j].set_title("Night 2" if j == 0 else "Night 4")
    ax[0].set_ylabel("$y_3$ [$^\\circ$C]")
    ax[0].legend(loc="upper right", fontsize=6)
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG_DIR, "fig_tube.pdf"))
    plt.close(fig)


def fig_bars(plt, M):
    fig, ax = plt.subplots(1, 4, figsize=(7.16, 1.7))
    ctrls = ["RB", "NMPC", "KA-EMPC"]
    xs = np.arange(2)
    wdt = 0.26
    items = [("Tlo", "rate", "$y_3<15^\\circ$C [% samples]"),
             ("RH", "rate", "$y_4>70$% [% samples]"),
             ("heat_kWh", None, "Heat [kWh m$^{-2}$]"),
             ("smooth_RMS", None, "RMS $\\|\\Delta u\\|$ (norm.)")]
    for a, (key, sub, lab) in enumerate(items):
        for j, c in enumerate(ctrls):
            vals = [M[s][c][key][sub] if sub else M[s][c][key] for s in ["summer", "winter"]]
            ax[a].bar(xs + (j - 1) * wdt, vals, wdt, color=COL[c], label=LAB[c])
        ax[a].set_xticks(xs)
        ax[a].set_xticklabels(["Summer", "Winter"])
        ax[a].set_title(lab)
        ax[a].grid(axis="x", visible=False)
    ax[0].legend(fontsize=6, loc="upper right")
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG_DIR, "fig_bars.pdf"))
    plt.close(fig)


def fig_sweep(plt, S):
    fig, ax = plt.subplots(1, 2, figsize=(3.5, 1.9))
    for j, s in enumerate(["summer", "winter"]):
        betas = sorted(S[s].keys(), key=float)
        viol = [S[s][b]["Tlo"]["integral"] + S[s][b]["RH"]["integral"] / 10.0 for b in betas]
        cost = [S[s][b]["heat_EUR"] + S[s][b]["co2_EUR"] for b in betas]
        ax[j].plot(cost, viol, "-o", color=COL["KA-EMPC"], ms=3)
        for b, cx, vy in zip(betas, cost, viol):
            # beta = 2 is drawn below its marker so that it does not collide
            # with the beta = 3 label when the two points lie close together
            off, ha = ((0, -9), "center") if float(b) == 2.0 else ((4, 3), "left")
            ax[j].annotate(f"$\\beta={float(b):g}$", (cx, vy), textcoords="offset points",
                           xytext=off, ha=ha, fontsize=6)
        ax[j].margins(x=0.18, y=0.18)
        ax[j].set_xlabel("Cost [EUR m$^{-2}$]")
        ax[j].set_title("Summer" if s == "summer" else "Winter")
    ax[0].set_ylabel("Violation integral")
    fig.tight_layout(pad=0.3)
    fig.savefig(os.path.join(FIG_DIR, "fig_sweep.pdf"))
    plt.close(fig)


# ---------------------------------------------------------------------------
# 8. LaTeX export: every number quoted in the paper comes from here
# ---------------------------------------------------------------------------
def _fmt(v, nd=2):
    return f"{v:.{nd}f}"


def write_latex(M, S, R, days, out_dir):
    """Write results_macros.tex (\\res{key}) and results_table.tex."""
    lines = ["% Auto-generated by ka_empc_greenhouse.py -- do not edit by hand.",
             "\\makeatletter",
             "\\newcommand{\\res}[1]{\\@ifundefined{res@#1}{\\textbf{??}}{\\csname res@#1\\endcsname}}",
             "\\newcommand{\\setres}[2]{\\expandafter\\def\\csname res@#1\\endcsname{#2}}",
             "\\makeatother"]

    def put(key, val):
        val = str(val)
        if val.startswith("-"):                       # typographic minus sign
            val = "$-$" + val[1:]
        lines.append(f"\\setres{{{key}}}{{{val}}}")

    put("days", days)
    put("steps", days * STEPS_PER_DAY)
    put("nu", KRLS().nu)
    for s in ["summer", "winter"]:
        w = R[s]["RB"]["weather"]
        put(f"{s}/radmax", f"{w[:, 0].max():.0f}")
        put(f"{s}/tmin", f"{w[:, 2].min():.1f}")
        put(f"{s}/tmax", f"{w[:, 2].max():.1f}")
        put(f"{s}/prior_rmse_T", _fmt(M["prior_rmse_T"][s]))
        for c in ["RB", "NMPC", "KA-EMPC"]:
            m = M[s][c]
            for con in ["Tlo", "Thi", "RH"]:
                put(f"{c}/{s}/{con}/rate", _fmt(m[con]["rate"]))
                put(f"{c}/{s}/{con}/avg", _fmt(m[con]["avg_period"], 1))
                put(f"{c}/{s}/{con}/max", m[con]["max_period"])
                put(f"{c}/{s}/{con}/size", _fmt(m[con]["max_size"]))
                put(f"{c}/{s}/{con}/int", _fmt(m[con]["integral"]))
            put(f"{c}/{s}/heat", _fmt(m["heat_kWh"]))
            put(f"{c}/{s}/heatEUR", _fmt(m["heat_EUR"], 3))
            put(f"{c}/{s}/co2", _fmt(1e3 * m["co2_kg"], 1))
            put(f"{c}/{s}/cost", _fmt(m["heat_EUR"] + m["co2_EUR"], 3))
            put(f"{c}/{s}/dw", _fmt(m["dw_gain_g"]))
            put(f"{c}/{s}/profit", _fmt(m["profit_EUR"], 3))
            put(f"{c}/{s}/smooth", _fmt(m["smooth_RMS"], 3))
            put(f"{c}/{s}/vent", _fmt(m["vent_mean"]))
            if "cpu_mean" in m:
                put(f"{c}/{s}/cpu", _fmt(m["cpu_mean"]))
                put(f"{c}/{s}/cpumax", _fmt(m["cpu_max"]))
            if "feas_share" in m:
                put(f"{c}/{s}/feas", _fmt(100 * m["feas_share"], 1))
                put(f"{c}/{s}/feasnohi", _fmt(100 * m["feas_share_nohi"], 1))
            if "inf_rh_share" in m:
                put(f"{c}/{s}/infrh", _fmt(100 * m["inf_rh_share"], 0))
                put(f"{c}/{s}/inftail", _fmt(100 * m["inf_tail_share"], 0))
        k = M[s]["KA-EMPC"]
        put(f"KA-EMPC/{s}/rmseT", _fmt(k["rmse_T"], 3))
        put(f"KA-EMPC/{s}/coverT", _fmt(100 * k["cover_beta2"][1], 1))
        put(f"KA-EMPC/{s}/coverH", _fmt(100 * k["cover_beta2"][2], 1))
        put(f"KA-EMPC/{s}/dict", k["dict_final"])
        put(f"KA-EMPC/{s}/dict0", int(R[s]["KA-EMPC"]["dict"][0]))
        put(f"KA-EMPC/{s}/switch", k["n_switch"])
        put(f"KA-EMPC/{s}/reject", k["n_reject"])
        put(f"KA-EMPC/{s}/fallback", k["n_switch_fallback"])
        put(f"KA-EMPC/{s}/sigma", _fmt(k["sigma_mean"], 3))
        # relative changes of KA-EMPC with respect to the two benchmarks [%]
        for b in ["RB", "NMPC"]:
            mb = M[s][b]

            def rel(a, bb):
                return 100.0 * (a - bb) / bb if abs(bb) > 1e-12 else 0.0
            put(f"rel/{s}/{b}/heat", _fmt(rel(k["heat_kWh"], mb["heat_kWh"]), 1))
            put(f"rel/{s}/{b}/cost", _fmt(rel(k["heat_EUR"] + k["co2_EUR"], mb["heat_EUR"] + mb["co2_EUR"]), 1))
            put(f"rel/{s}/{b}/profit", _fmt(rel(k["profit_EUR"], mb["profit_EUR"]), 1))
            put(f"rel/{s}/{b}/smooth", _fmt(rel(k["smooth_RMS"], mb["smooth_RMS"]), 1))
            for con in ["Tlo", "RH"]:
                put(f"rel/{s}/{b}/{con}int", _fmt(rel(k[con]["integral"], mb[con]["integral"]), 1))
        if S:
            for b, m in S[s].items():
                bb = f"{float(b):g}"
                put(f"sweep/{s}/{bb}/Tlo", _fmt(m["Tlo"]["rate"]))
                put(f"sweep/{s}/{bb}/RH", _fmt(m["RH"]["rate"]))
                if "feas_share" in m:
                    put(f"sweep/{s}/{bb}/feas", _fmt(100 * m["feas_share"], 1))
                    put(f"sweep/{s}/{bb}/feasnohi", _fmt(100 * m["feas_share_nohi"], 1))
                put(f"sweep/{s}/{bb}/Tloint", _fmt(m["Tlo"]["integral"]))
                put(f"sweep/{s}/{bb}/RHint", _fmt(m["RH"]["integral"]))
                put(f"sweep/{s}/{bb}/cost", _fmt(m["heat_EUR"] + m["co2_EUR"], 3))
                put(f"sweep/{s}/{bb}/heat", _fmt(m["heat_kWh"]))
                put(f"sweep/{s}/{bb}/profit", _fmt(m["profit_EUR"], 3))
    with open(os.path.join(out_dir, "results_macros.tex"), "w") as f:
        f.write("\n".join(lines) + "\n")

    # ---- main comparison table (table* spanning both columns) ----
    C = ["RB", "NMPC", "KA-EMPC"]
    rows = []

    def row(label, fn, unit, best=None):
        vals = [[fn(M[s][c]) for c in C] for s in ["summer", "winter"]]
        cells = []
        for v in vals:
            nums = [x[0] for x in v]
            ib = None
            if best == "min":
                ib = int(np.argmin(nums))
            elif best == "max":
                ib = int(np.argmax(nums))
            # bold every entry tied with the best (as printed); none if all tie
            bt = v[ib][1] if ib is not None else None
            if bt is not None and all(t == bt for _, t in v):
                bt = None
            for num, txt in v:
                shown = "$-$" + txt[1:] if txt.startswith("-") else txt   # typographic minus
                cells.append(f"\\textbf{{{shown}}}" if txt == bt else shown)
        rows.append(f"{label} & {unit} & " + " & ".join(cells) + " \\\\")

    def g(key, sub=None, nd=2, scale=1.0):
        def f(m):
            v = (m[key][sub] if sub else m[key]) * scale
            return (v, f"{v:.{nd}f}" if nd > 0 else f"{int(round(v))}")
        return f

    rows.append("\\multicolumn{8}{@{}l}{\\textit{Minimum temperature, $y_3\\ge15\\,^\\circ$C}} \\\\")
    row("\\quad violation rate", g("Tlo", "rate"), "\\%", "min")
    row("\\quad avg./max. episode", lambda m: (m["Tlo"]["max_period"],
        f"{m['Tlo']['avg_period']:.1f}/{m['Tlo']['max_period']}"), "samples", None)
    row("\\quad max. violation", g("Tlo", "max_size"), "K", "min")
    row("\\quad violation integral", g("Tlo", "integral"), "K\\,h", "min")
    rows.append("\\multicolumn{8}{@{}l}{\\textit{Maximum temperature, $y_3\\le25\\,^\\circ$C}} \\\\")
    row("\\quad violation rate", g("Thi", "rate"), "\\%", "min")
    row("\\quad violation integral", g("Thi", "integral"), "K\\,h", "min")
    rows.append("\\multicolumn{8}{@{}l}{\\textit{Humidity, $y_4\\le70$\\,\\%}} \\\\")
    row("\\quad violation rate", g("RH", "rate"), "\\%", "min")
    row("\\quad avg./max. episode", lambda m: (m["RH"]["max_period"],
        f"{m['RH']['avg_period']:.1f}/{m['RH']['max_period']}"), "samples", None)
    row("\\quad max. violation", g("RH", "max_size"), "\\%", "min")
    row("\\quad violation integral", g("RH", "integral", 1), "\\%\\,h", "min")
    rows.append("\\multicolumn{8}{@{}l}{\\textit{Resources and economics (per m$^2$ over the scenario)}} \\\\")
    row("\\quad heating energy", g("heat_kWh"), "kWh", "min")
    row("\\quad CO$_2$ supplied", g("co2_kg", None, 1, 1e3), "g", None)
    row("\\quad heating + CO$_2$ cost", lambda m: (m["heat_EUR"] + m["co2_EUR"],
        f"{m['heat_EUR'] + m['co2_EUR']:.3f}"), "EUR", "min")
    row("\\quad dry-weight gain", g("dw_gain_g"), "g", "max")
    row("\\quad profit", g("profit_EUR", None, 3), "EUR", "max")
    rows.append("\\multicolumn{8}{@{}l}{\\textit{Actuation and computation}} \\\\")
    row("\\quad RMS normalized move", g("smooth_RMS", None, 3), "--", "min")
    row("\\quad mean solve time", lambda m: (m.get("cpu_mean", 0.0),
        f"{m['cpu_mean']:.2f}" if "cpu_mean" in m else "--"), "s", None)
    tab = ["% Auto-generated by ka_empc_greenhouse.py -- do not edit by hand.",
           "\\begin{table*}[t]", "\\centering",
           f"\\caption{{Closed-loop performance over {days} days. Bold marks the best value per scenario (all tied values; none if all controllers tie).}}",
           "\\label{tab:results}", "\\small",
           "\\resizebox{\\textwidth}{!}{%", "\\begin{tabular}{@{}llcccccc@{}}", "\\toprule",
           " & & \\multicolumn{3}{c}{Summer} & \\multicolumn{3}{c}{Winter} \\\\",
           "\\cmidrule(lr){3-5}\\cmidrule(l){6-8}",
           "Metric & Unit & RB & NMPC & KA-EMPC & RB & NMPC & KA-EMPC \\\\", "\\midrule"]
    tab += rows + ["\\bottomrule", "\\end{tabular}}", "\\end{table*}"]
    with open(os.path.join(out_dir, "results_table.tex"), "w") as f:
        f.write("\n".join(tab) + "\n")


# ---------------------------------------------------------------------------
# 9. Main
# ---------------------------------------------------------------------------
def _job(args):
    ctrl, season, days, beta = args
    t0 = time.perf_counter()
    res = simulate(ctrl, season, days, beta=beta)
    print(f"  {ctrl:9s} {season:6s} beta={beta:3.1f} done in {time.perf_counter() - t0:6.1f} s",
          flush=True)
    return (ctrl, season, beta), res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--procs", type=int, default=4)
    ap.add_argument("--no-sweep", action="store_true")
    ap.add_argument("--plot-only", action="store_true",
                    help="re-draw figures/tables from results_raw.pkl")
    a = ap.parse_args()
    os.makedirs(FIG_DIR, exist_ok=True)
    days = a.days
    beta_main = 2.0
    jobs = [(c, s, days, beta_main) for s in ["summer", "winter"] for c in ["RB", "NMPC", "KA-EMPC"]]
    sweep = [] if a.no_sweep else [("KA-EMPC", s, days, b) for s in ["summer", "winter"]
                                   for b in [0.0, 1.0, 3.0]]
    raw = os.path.join(os.path.dirname(FIG_DIR), "results_raw.pkl")
    if a.plot_only:
        with open(raw, "rb") as f:
            out = pickle.load(f)
    else:
        print(f"Running {len(jobs) + len(sweep)} closed-loop simulations ({days} days each)")
        with Pool(a.procs) as pool:
            out = dict(pool.map(_job, jobs + sweep))
        with open(raw, "wb") as f:
            pickle.dump(out, f)
    R = {s: {c: out[(c, s, beta_main)] for c in ["RB", "NMPC", "KA-EMPC"]} for s in ["summer", "winter"]}
    M = {s: {c: metrics(R[s][c]) for c in R[s]} for s in R}
    S = {}
    if sweep:
        for s in ["summer", "winter"]:
            S[s] = {str(b): metrics(out[("KA-EMPC", s, b)]) for b in [0.0, 1.0, 3.0]}
            S[s]["2.0"] = M[s]["KA-EMPC"]
    M["prior_rmse_T"] = {s: prior_error(s, days) for s in ["summer", "winter"]}
    with open(os.path.join(os.path.dirname(FIG_DIR), "results.json"), "w") as f:
        json.dump({"main": M, "sweep": S, "days": days}, f, indent=1)
    write_latex(M, S, R, days, os.path.dirname(FIG_DIR))
    plt = setup_mpl()
    fig_weather(plt, R, days)
    fig_outputs(plt, R, days)
    fig_inputs(plt, R, days)
    fig_learning(plt, R, days)
    fig_tube(plt, R)
    fig_bars(plt, M)
    if sweep:
        fig_sweep(plt, S)
    # console summary
    for s in ["summer", "winter"]:
        print(f"\n=== {s} ===")
        for c in ["RB", "NMPC", "KA-EMPC"]:
            m = M[s][c]
            print(f"{c:8s} Tlo {m['Tlo']['rate']:5.2f}% (max {m['Tlo']['max_period']:3d}, "
                  f"{m['Tlo']['max_size']:.2f}K) Thi {m['Thi']['rate']:5.2f}% RH {m['RH']['rate']:5.2f}% "
                  f"(max {m['RH']['max_size']:.2f}) heat {m['heat_kWh']:.2f} kWh "
                  f"cost {m['heat_EUR'] + m['co2_EUR']:.3f} profit {m['profit_EUR']:.3f} "
                  f"dw {m['dw_gain_g']:.2f} g RMSdu {m['smooth_RMS']:.3f} "
                  f"cpu {m.get('cpu_mean', 0):.3f}")
    print("\nprior one-step RMSE T:", M["prior_rmse_T"])


if __name__ == "__main__":
    main()
