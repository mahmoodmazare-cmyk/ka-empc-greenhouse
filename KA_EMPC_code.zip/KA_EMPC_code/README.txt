KA-EMPC greenhouse study: simulation code and data
==================================================

Supplementary material to "Uncertainty-Aware Adaptive Economic MPC via
Kernel Learning for Robust Greenhouse Climate Management".

The script reproduces every figure of Section 7 (Figs. 3-8), Table 5 and
the numbers quoted in Section 7, the abstract and the conclusions;
check_text_numbers.py recomputes the few remaining ones.

Contents
  ka_empc_greenhouse.py   the complete study in one file:
                            van Henten lettuce greenhouse model (plant and
                            mis-calibrated prior), synthetic weather and
                            forecast errors, KRLS learner with ALD dictionary,
                            rule-based controller, offset-free nominal NMPC,
                            KA-EMPC, metrics, figures and LaTeX output
  check_text_numbers.py   recomputes from results_raw.pkl the few numbers of
                          Section 7 that are not written to results_macros.tex
                          (ventilation and heating averages, prior bias, tube
                          widths, timing of dictionary growth)
  requirements.txt        Python packages and the versions used for the paper
  results/                output of the run reported in the paper
    results.json            all metrics, machine-readable
    results_raw.pkl         closed-loop trajectories of all 12 runs
                            (pickle of a dict keyed by (controller, season, beta))
    results_macros.tex      numbers quoted in the manuscript
    results_table.tex       Table 5
    FIG/                    figures as PDF

Requirements
  Python 3.10 or later; packages in requirements.txt
    pip install -r requirements.txt

Usage
  python3 ka_empc_greenhouse.py --procs 4
      Full study: 6 main runs (3 controllers x 2 seasons, beta = 2) and
      6 sweep runs (KA-EMPC, beta = 0, 1, 3). Writes FIG/, results.json,
      results_raw.pkl, results_macros.tex and results_table.tex into the
      folder of the script. Run time: about 30 min on four cores.
  python3 ka_empc_greenhouse.py --no-sweep
      Main comparison only.
  python3 ka_empc_greenhouse.py --days 1 --no-sweep
      One-day smoke test (a few minutes).
  python3 ka_empc_greenhouse.py --plot-only
      Re-draws figures and tables from an existing results_raw.pkl.
  python3 check_text_numbers.py
      Prints the remaining numbers quoted in Section 7 (run after the study).

Reproducibility
  All random quantities (weather, forecast errors, process noise) are drawn
  from seeded generators. With the package versions in requirements.txt the
  script reproduces the reported numbers; solve times depend on the machine.
  Other versions of SciPy may change the SLSQP iterates slightly and hence the
  last digits of some results.

Correspondence with the paper
  Section 3 (model, constraints)      rhs, plant_step, prior_step, outputs,
                                      constants at the top of the file
  Section 4 (KRLS learner)            class KRLS
  Section 5 (base policy pi)          kappa
  Section 6.5 and Table 3             class EconomicMPC (KA-EMPC and NMPC:
  (implemented controller)            tube propagation, soft_plus penalties,
                                      fallback switch rule)
  Section 7.1 (set-up, weather)       make_weather, forecast, process_noise,
                                      warm_start_data, simulate, RuleBased
  Sections 7.2-7.6 (results)          metrics, prior_error, write_latex, fig_*
